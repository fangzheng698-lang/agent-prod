"""质量门体系 — 可运行的企业级 Quality Gate 实现"""
